package pro3;

public class Demo2 {
public static void main(String[] args) {
	double x=3.99;
	int a=(int)x;
	char b='a';
	int c=b+1;
	System.out.println(a);
	System.out.println((int)b);
	System.out.println((char)c);
}
}
