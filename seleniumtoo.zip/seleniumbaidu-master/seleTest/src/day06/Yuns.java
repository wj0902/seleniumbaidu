package day06;

public class Yuns {
	//@Test
	public int add(int a,int b) {
		return a+b;
	}
	
	public int sub(int a,int b) {
		return a-b;
	}
	
	public int cheng(int a,int b) {
		return a*b;
	}
	
	public int chu(int a,int b) {
		return a/b;
	}
}
